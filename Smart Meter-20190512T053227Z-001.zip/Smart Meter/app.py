# __author__='Prateek_Gulati'

from flask import Flask
from flask import request
import regex as re
import os
import numpy as np

app = Flask(__name__)
app.config["DEBUG"] = True
# port = int(os.getenv("PORT"))





@app.route('/', methods=['GET'])
def home():
    return "<h1>Server</h1>This is a prototype API to simulate the appliances running at home."

@app.route('/api/home/devices/', methods=['GET']) # http://127.0.0.1:5000/home/devices?ac=on&ref=on&wash=on
def getId():
    consumption=0.0
    var=0.0
    response=""
    if 'ac' in request.args:
        ac = request.args['ac']
    else:
        return "AC missing"
    if 'ref' in request.args:
        ref = request.args['ref']
    else:
        return "Refrigerator missing"
    if 'wash' in request.args:
        wash = request.args['wash']
    else:
        return "Washing Machine missing"
    if ac=='on':
        response += "AC is on\n"
        consumption=consumption+100.0
        var=var+0.2
    if ref=='on':
        response += "Refrigerator is on\n"
        consumption =consumption+ 70.0
        var=var+0.1
    if wash=='on':
        response += "Washing Machine is on\n"
        consumption =consumption+ 50.0
        var=var+1.0
    # return str
    return response+'<br>'+str(np.random.uniform(consumption,consumption+var))

# @app.route('/api/v1/resources/version', methods=['GET']) # http://127.0.0.1:5000/api/v1/resources/version?no=v1
# def getVersion():
#     if 'no' in request.args:
#         no = request.args['no']
#     else:
#         return "Error: No Version number provided. Please specify a number."
#     if validateVersion(no):
#          return "Valid Version"
#     return "Invalid Version"
#
# @app.route('/api/v1/resources/service', methods=['GET']) # http://127.0.0.1:5000/api/v1/resources/service?name=bas
# def getService():
#     if 'name' in request.args:
#         name = request.args['name']
#     else:
#         return "Error: No Service Name provided. Please specify a service."
#     if validateService(name):
#          return "Valid Service"
#     return "Invalid Service"
#
#
# @app.route('/api/v1/resources', methods=['GET']) # http://127.0.0.1:5000/api/v1/resources?id=3673658&no=v2&name=enh
# def getEntities():
#     if 'id' in request.args:
#         id = request.args['id']
#         if not validateId(id):
#             return "Invalid Oppurtunity Id. It should be exactly 7 digits and begin from 3 or 4. Eg. Opp Id 4123456 Version v1 Service BAS"
#     else:
#         return "Error: No id field provided. Please specify an Oppurtunity Id. Eg. Opp Id 4123456 Version v1 Service BAS"
#
#     if 'no' in request.args:
#         no = request.args['no']
#         if not validateVersion(no):
#             return "Invalid Version. Version should begin with v followed by number. Eg. Opp Id 4123456 Version v1 Service BAS"
#     else:
#         return "Error: No Version field provided. Please specify a version number. Eg. Opp Id 4123456 Version v1 Service BAS"
#
#     if 'name' in request.args:
#         name = request.args['name']
#         if not validateService(name):
#             return "Invalid Service Level. \n\n Service name can be only BAS/ENH/PRE/NBD/SMC. Eg. Opp Id 4123456 Version v1 Service BAS"
#     else:
#         return "Error: No service field provided. Please specify a service name. Eg. Opp Id 4123456 Version v1 Service BAS"
#
#     storeEntity(request.args)
#     return "Success"
#
# @app.route('/api/v1/helpabc', methods=['GET'])
# def helpabc():
#     return "Syntax: Opp id 4556211 version v1 service BAS. \n <br/> Service list: \n BAS: Basic \n ENH: Enhanced \n ABC/XYZ"
#


if __name__ == '__main__':
    app.run()